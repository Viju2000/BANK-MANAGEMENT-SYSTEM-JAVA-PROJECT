
package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class SignUpThree extends JFrame implements ActionListener{
    JLabel l1,type,card,number,message1,pin,message2,number1,service;
    JRadioButton tsaving,tfixed,tcurrent,treversing;
    JCheckBox tatm,tinternet,tmobile,temail,tcheque,te,thereby;
    JButton tsubmit,tcancel;
    ButtonGroup typegroup; 
    String formno;
    
    SignUpThree(String formno) {
        this.formno = formno;
        setLayout(null);
        l1 = new JLabel("Page 3: Account Details");
        l1.setFont(new Font("Raleway",Font.BOLD,22));
        l1.setBounds(280,40,400,40);
        add(l1);
        
        type = new JLabel("Account Type:");
        type.setFont(new Font("Raleway",Font.BOLD,22));
        type.setBounds(100,140,200,30);
        add(type);
        
        tsaving = new JRadioButton("Saving Account");
        tsaving.setBackground(Color.WHITE);
        tsaving.setFont(new Font("Raleway",Font.BOLD,16));
        tsaving.setBounds(120,180,145,30);
        add(tsaving);
        
        tfixed = new JRadioButton("Fixed Deposit Account");
        tfixed.setBackground(Color.WHITE);
        tfixed.setFont(new Font("Raleway",Font.BOLD,16));
        tfixed.setBounds(330,180,200,30);
        add(tfixed);
        
        tcurrent = new JRadioButton("Current Account");
        tcurrent.setBackground(Color.WHITE);
        tcurrent.setFont(new Font("Raleway",Font.BOLD,16));
        tcurrent.setBounds(120,210,150,30);
        add(tcurrent);
        
        treversing = new JRadioButton("Recursing Deposit Account");
        treversing.setBackground(Color.WHITE);
        treversing.setFont(new Font("Raleway",Font.BOLD,16));
        treversing.setBounds(330,210,240,30);
        add(treversing);
        
        typegroup = new ButtonGroup();
        typegroup.add(tsaving);
        typegroup.add(tfixed);
        typegroup.add(tcurrent);
        typegroup.add(treversing);
        
        card = new JLabel("Card Number:");
        card.setFont(new Font("Raleway",Font.BOLD,22));
        card.setBounds(100,260,300,30);
        add(card);
        
        number = new JLabel("XXXX-XXXX-XXXX-1784");
        number.setFont(new Font("Raleway",Font.BOLD,16));
        number.setBounds(380,260,190,30);
        add(number);
        
        message1 = new JLabel("Your 16 Digit Card Number");
        message1.setFont(new Font("Raleway",Font.BOLD,12));
        message1.setBounds(100,280,300,30);
        add(message1);
        
        pin= new JLabel("PIN:");
        pin.setFont(new Font("Raleway",Font.BOLD,22));
        pin.setBounds(100,320,150,30);
        add(pin);
        
        number1 = new JLabel("XXXX");
        number1.setFont(new Font("Raleway",Font.BOLD,16));
        number1.setBounds(380,320,100,30);
        add(number1);
        
        message2 = new JLabel("Your 16 Digit Card Number");
        message2.setFont(new Font("Raleway",Font.BOLD,12));
        message2.setBounds(100,340,300,30);
        add(message2);
        
        service = new JLabel("Service Required: ");
        service.setFont(new Font("Raleway",Font.BOLD,22));
        service.setBounds(100,390,200,30);
        add(service);
        
        tatm = new JCheckBox("ATM CARD");
        tatm.setBackground(Color.WHITE);
        tatm.setFont(new Font("Raleway",Font.BOLD,16));
        tatm.setBounds(120,430,110,30);
        add(tatm);
        
        tinternet = new JCheckBox("INTERNET BANKING");
        tinternet.setBackground(Color.WHITE);
        tinternet.setFont(new Font("Raleway",Font.BOLD,16));
        tinternet.setBounds(330,430,183,30);
        add(tinternet);
        
        tmobile = new JCheckBox("MOBILE BANKING");
        tmobile.setBackground(Color.WHITE);
        tmobile.setFont(new Font("Raleway",Font.BOLD,16));
        tmobile.setBounds(120,460,163,30);
        add(tmobile);
        
        temail = new JCheckBox("EMAIL & SMS ALERT");
        temail.setBackground(Color.WHITE);
        temail.setFont(new Font("Raleway",Font.BOLD,16));
        temail.setBounds(330,460,185,30);
        add(temail);
        
        tcheque = new JCheckBox("CHEQUE BOOK");
        tcheque.setBackground(Color.WHITE);
        tcheque.setFont(new Font("Raleway",Font.BOLD,16));
        tcheque.setBounds(120,490,150,30);
        add(tcheque);
        
        te = new JCheckBox("E-STATEMENT");
        te.setBackground(Color.WHITE);
        te.setFont(new Font("Raleway",Font.BOLD,16));
        te.setBounds(330,490,140,30);
        add(te);
        
        thereby = new JCheckBox("I hereby declare that the above entered details are corerect to the best of my knowledge.");
        thereby.setBackground(Color.WHITE);
        thereby.setFont(new Font("Raleway",Font.BOLD,12));
        thereby.setBounds(100,580,525,30);
        add(thereby);
        
        tsubmit =  new JButton("SUBMIT ");
        tsubmit.setBackground(Color.BLACK);
        tsubmit.setForeground(Color.WHITE);
        tsubmit.setFont(new Font("Raleway",Font.BOLD,12));
        tsubmit.setBounds(200,700,100,30);
        tsubmit.addActionListener(this);
        add(tsubmit);
        
        
        tcancel =  new JButton("CANCEL");
        tcancel.setBackground(Color.BLACK);
        tcancel.setForeground(Color.WHITE);
        tcancel.setFont(new Font("Raleway",Font.BOLD,12));
        tcancel.setBounds(430,700,100,30);
        tcancel.addActionListener(this);

        add(tcancel);
        
        getContentPane().setBackground(Color.WHITE);
        
        
        
        
        
        
        
        
        
        
        
        setSize(850,820);
        setLocation(350,0);
        setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == tsubmit){
            String accountType = null;
            String Messages = null;
            if(tsaving.isSelected()){
                accountType = "Saving Account";
            }else if(tfixed.isSelected()){
                accountType = "Fixed Deposit Account";
            }else if(tcurrent.isSelected())
            {
                accountType = "Current Account";
            }else if(treversing.isSelected()){
                accountType = "Reccuring Deposite Account";
            }
            
            Random random = new Random();
            String cardnumber = "" + Math.abs((random.nextLong() % 90000000L) + 5040936000000000L);
            String pinnumber = "" + Math.abs((random.nextLong() % 9000L) + 1000L);
            String facility = "";
            if(tatm.isSelected())
            {
                facility = facility + "Atm CARD";
            }else if(tinternet.isSelected()){
                facility = facility + "Internet Banking";
            }else if(tmobile.isSelected()){
                facility = facility + "Mobile Banking";
            }else if(temail.isSelected()){
                facility = facility + "Email and sms service";
            }else if(tcheque.isSelected()){
                facility = facility + "Cheque Book";
            }else if(te.isSelected()){
                facility = facility + "E-Statement";
            }
            
            try {
                if(accountType.equals("")){
                    JOptionPane.showMessageDialog(null,"Account Type is Required");
                }else {
                    Conn c = new Conn();
                    String query1 = "insert into SignUpThree values('"+formno+"','"+accountType+"','"+cardnumber+"','"+pinnumber+"','"+facility+"')";
                    String query2 = "insert into Login values('"+formno+"','"+cardnumber+"','"+pinnumber+"')";

                    c.s.executeUpdate(query1);
                    c.s.executeUpdate(query2);

                    
                    
                    JOptionPane.showMessageDialog(null, " Card Number: " +cardnumber+ "\n Pin number: " +pinnumber); 
                    setVisible(false);
                    new Deposit(pinnumber).setVisible(true);
                    //signupthree object
                    
                    
                }
            }catch(Exception e){
                System.out.println(e);
                      
            }
        }else if(ae.getSource() == tcancel){
            setVisible(false);
            new Login().setVisible(true);
            
        }
    }
    
    public static void main(String args[]) {
        new SignUpThree("");
    }
}
