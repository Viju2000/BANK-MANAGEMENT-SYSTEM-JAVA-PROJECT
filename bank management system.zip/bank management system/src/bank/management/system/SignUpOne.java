
package bank.management.system;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*; //action listeneer 
import java.util.*; //random class


public class SignUpOne extends JFrame implements ActionListener{
    long random;
    JTextField nameTextField,fnameTextField,emailTextField,addressTextField,cityTextField,stateTextField,pincTextField;
    JLabel formno,personalDetails,name,fname,dob,gender,email,mStatus,address,city,state,pinCode;
    JButton next;
    JRadioButton married,unmarried,other,male,female;
    JDateChooser dateChooser; 
    
    SignUpOne(){
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE1");
        setLayout(null);
        
        Random ran = new Random();
        random  = Math.abs((ran.nextLong() % 9000L) + 1000L);
        
        formno = new JLabel("APPLICATION FORM NO. " + random );
        formno.setFont(new Font("Raleway",Font.BOLD, 38));
        formno.setBounds(140,20,600,40);
        add(formno);
        
        personalDetails = new JLabel("Page 1: Personal Details");
        personalDetails.setFont(new Font("Raleway",Font.BOLD, 22));
        personalDetails.setBounds(290,80,300,40);
        add(personalDetails);
        
        name = new JLabel("Name: ");
        name.setFont(new Font("Raleway",Font.BOLD, 20));
        name.setBounds(100,140,100,30);
        add(name);
        
        nameTextField = new JTextField();
        nameTextField.setFont(new Font("Raleway",Font.BOLD,14));
        nameTextField.setBounds(300,140,400,30);
        add(nameTextField);
        
        fname = new JLabel("Father's Name: ");
        fname.setFont(new Font("Raleway",Font.BOLD, 20));
        fname.setBounds(100,180,150,30);
        add(fname);
        
        fnameTextField = new JTextField();
        fnameTextField.setFont(new Font("Raleway",Font.BOLD,14));
        fnameTextField.setBounds(300,180,400,30);
        add(fnameTextField);
        
        dob = new JLabel("Date Of Birth: ");
        dob.setFont(new Font("Raleway",Font.BOLD, 20));
        dob.setBounds(100,220,150,30);
        add(dob);
        
        dateChooser = new JDateChooser();
        dateChooser.setBounds(300,220,400,30);
        dateChooser.setForeground(new Color(105,105,105));
        add(dateChooser);
        
        
        gender = new JLabel("Gender: ");
        gender.setFont(new Font("Raleway",Font.BOLD, 20));
        gender.setBounds(100,260,150,30);
        add(gender);
        
        male = new JRadioButton("MALE");
        male.setBounds(300,260,60,30);
        male.setBackground(Color.WHITE);
        add(male);
        
        female = new JRadioButton("FEMALE");
        female.setBounds(450,260,90,30);
        female.setBackground(Color.WHITE);
        add(female);
        
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(male);
        genderGroup.add(female);
        
        
        email = new JLabel("E-Mail: ");
        email.setFont(new Font("Raleway",Font.BOLD, 20));
        email.setBounds(100,300,150,30);
        add(email);
        
        emailTextField = new JTextField();
        emailTextField.setFont(new Font("Raleway",Font.BOLD,14));
        emailTextField.setBounds(300,300,400,30);
        add(emailTextField);
        
        mStatus = new JLabel("Marital Status: ");
        mStatus.setFont(new Font("Raleway",Font.BOLD, 20));
        mStatus.setBounds(100,340,150,30);
        add(mStatus);
        
        married = new JRadioButton("MARRIED");
        married.setBounds(300,340,100,30);
        married.setBackground(Color.WHITE);
        add(married);
      
        unmarried = new JRadioButton("UNMARRIED");
        unmarried.setBounds(400,340,130,30);
        unmarried.setBackground(Color.WHITE);
        add(unmarried);
        
        other = new JRadioButton("OTHER");
        other.setBounds(530,340,100,30);
        other.setBackground(Color.WHITE);
        add(other);
       
        ButtonGroup maritalstatus = new ButtonGroup();
        maritalstatus.add(married);
        maritalstatus.add(unmarried);
        maritalstatus.add(other);
        
        address = new JLabel("Address: ");
        address.setFont(new Font("Raleway",Font.BOLD, 20));
        address.setBounds(100,380,150,30);
        add(address);
        
        addressTextField = new JTextField();
        addressTextField.setFont(new Font("Raleway",Font.BOLD,14));
        addressTextField.setBounds(300,380,400,30);
        add(addressTextField);
        
        city = new JLabel("City: ");
        city.setFont(new Font("Raleway",Font.BOLD, 20));
        city.setBounds(100,420,150,30);
        add(city);
        
        cityTextField = new JTextField();
        cityTextField.setFont(new Font("Raleway",Font.BOLD,14));
        cityTextField.setBounds(300,420,400,30);
        add(cityTextField);

        state = new JLabel("State: ");
        state.setFont(new Font("Raleway",Font.BOLD, 20));
        state.setBounds(100,460,150,30);
        add(state);
        
        stateTextField = new JTextField();
        stateTextField.setFont(new Font("Raleway",Font.BOLD,14));
        stateTextField.setBounds(300,460,400,30);
        add(stateTextField);
        
        pinCode = new JLabel("PinCode: ");
        pinCode.setFont(new Font("Raleway",Font.BOLD, 20));
        pinCode.setBounds(100,500,150,30);
        add(pinCode);
        
        pincTextField = new JTextField();
        pincTextField.setFont(new Font("Raleway",Font.BOLD,14));
        pincTextField.setBounds(300,500,400,30);
        add(pincTextField);
        
        next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway",Font.BOLD,20));
        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);
        
        
        

        
        
        getContentPane().setBackground(Color.WHITE);
        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
        
    }
    public void actionPerformed(ActionEvent e){
        String formno = "" + random; // form no is long value , this converts long to string 
        String name = nameTextField.getText();
        String fname = nameTextField.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText(); //getui - textfield access. concat to textfield
        String gender = null;
        if(male.isSelected()){
            gender="Male";
        }
        else if(female.isSelected()){
            gender="Female";
        }
        String email = emailTextField.getText();
        String mstatus = null;
        if(married.isSelected()){
            mstatus = "married";
        }
        else if(unmarried.isSelected()){
            mstatus="unmarried";
        }
        else if(other.isSelected()){
            mstatus="other";
        }
        
       String address = addressTextField.getText();
       String city = cityTextField.getText();
       String state = stateTextField.getText();
       String pinc = pincTextField.getText();
        
       try{
           if(name.equals("")){
               JOptionPane.showMessageDialog(null,"Name Is Requied");// to popup error  
           }
           else{
               Conn c = new Conn();
               String query = "insert into signup values('"+formno+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"','"+mstatus+"','"+address+"','"+city+"','"+state+"','"+pinc+"')";
               c.s.executeUpdate(query); 
               
               setVisible(false);
               new SignUpTwo(formno).setVisible(true);
           }
           
       }catch (Exception a){
           System.out.println(a); 
       }
    }
    public static void main(String args[]) {
      new SignUpOne();
    }
}
