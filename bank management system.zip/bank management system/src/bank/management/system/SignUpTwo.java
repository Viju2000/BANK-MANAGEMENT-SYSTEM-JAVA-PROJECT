
package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*; //action listeneer 



public class SignUpTwo extends JFrame implements ActionListener{
    long random;
    JTextField aadhar,pan;
    JComboBox religion,category,income,education,occupation;
    JLabel additionalDetails,religionName,categoryWise,incomeNo,educationDetails,qualify,occupat,panno,aadharNo,senior,existingA;
    JButton next;
    JRadioButton sYes,sNo,eYes,eNo;
    String formno;
    
    
    
    SignUpTwo(String formno){
        this.formno = formno;
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE2");
        setLayout(null);
  
        additionalDetails = new JLabel("Page 2: Additional Details");
        additionalDetails.setFont(new Font("Raleway",Font.BOLD, 22));
        additionalDetails.setBounds(290,80,300,40);
        add(additionalDetails);
        
        religionName= new JLabel("Religion: ");
        religionName.setFont(new Font("Raleway",Font.BOLD, 19));
        religionName.setBounds(100,140,100,30);
        add(religionName);
        
        String valReligion[] = {"Select","Hindu","Muslim","sikh","Christian","Others"};
        religion = new JComboBox(valReligion);
        religion.setBounds(300,140,400,30);
        religion.setBackground(Color.WHITE); 
        add(religion);
        
        
        categoryWise = new JLabel("Category: ");
        categoryWise.setFont(new Font("Raleway",Font.BOLD, 19));
        categoryWise.setBounds(100,180,150,30);
        add(categoryWise);
        
        String valCategory[] = {"Select","General","OBC","SC","ST","Others"};
        category = new JComboBox(valCategory);
        category.setBounds(300,180,400,30);
        category.setBackground(Color.WHITE);
        add(category);
        
        
        incomeNo = new JLabel("Income: ");
        incomeNo.setFont(new Font("Raleway",Font.BOLD, 19));
        incomeNo.setBounds(100,220,150,30);
        add(incomeNo);
        
        String valIncome[] = {"Select","NULL","< 1,50,000","< 2,50,000","< 5,00,000","Upto 10,00,000"};
        income = new JComboBox(valIncome);
        income.setBounds(300,220,400,30);
        income.setBackground(Color.WHITE); 
        add(income);
        
        
        educationDetails = new JLabel("Educational ");
        educationDetails.setFont(new Font("Raleway",Font.BOLD, 19));
        educationDetails.setBounds(100,260,150,30);
        add(educationDetails);
        
        qualify = new JLabel("Qualification:");
        qualify.setFont(new Font("Raleway",Font.BOLD, 19));
        qualify.setBounds(100,285,150,30);
        add(qualify);
        
        String educationVal[] = {"Select","Non-Graduate","Graduation","Post-Graduate","Doctrate","Others"};
        education = new JComboBox(educationVal);
        education.setBounds(300,285,400,30);
        education.setBackground(Color.WHITE); 
        add(education);
        
   
        occupat = new JLabel("Occupation: ");
        occupat.setFont(new Font("Raleway",Font.BOLD, 19));
        occupat.setBounds(100,340,150,30);
        add(occupat);
        
        String occupVal[] = {"Select","Salaried","Self-Employed","BussinessMan","Student","retired","others"};
        occupation = new JComboBox(occupVal);
        occupation.setBounds(300,340,400,30);
        occupation.setBackground(Color.WHITE); 
        add(occupation);
        
        
        panno = new JLabel("Pan.No: ");
        panno.setFont(new Font("Raleway",Font.BOLD, 19));
        panno.setBounds(100,380,150,30);
        add(panno);
        
        pan = new JTextField();
        pan.setFont(new Font("Raleway",Font.BOLD,19));
        pan.setBounds(300,380,400,30);
        add(pan);
        
        aadharNo = new JLabel("Aadhar: ");
        aadharNo.setFont(new Font("Raleway",Font.BOLD, 19));
        aadharNo.setBounds(100,420,150,30);
        add(aadharNo);
        
        aadhar = new JTextField();
        aadhar.setFont(new Font("Raleway",Font.BOLD,19));
        aadhar.setBounds(300,420,400,30);
        add(aadhar);

     
        senior = new JLabel("Senior Citizen: ");
        senior.setFont(new Font("Raleway",Font.BOLD, 19));
        senior.setBounds(100,460,150,30);
        add(senior);
        
        sYes = new JRadioButton("YES");
        sYes.setBounds(300,465,60,30);
        sYes.setBackground(Color.WHITE);
        add(sYes);
        
        sNo = new JRadioButton("NO");
        sNo.setBounds(450,465,90,30);
        sNo.setBackground(Color.WHITE);
        add(sNo);
        
        ButtonGroup seniorGroup = new ButtonGroup();
        seniorGroup.add(sYes);
        seniorGroup.add(sNo);
        
        existingA = new JLabel("Existing Account: ");
        existingA.setFont(new Font("Raleway",Font.BOLD, 19));
        existingA.setBounds(100,490,170,30);
        add(existingA);
        
        eYes = new JRadioButton("YES");
        eYes.setBounds(300,495,60,30);
        eYes.setBackground(Color.WHITE);
        add(eYes);
        
        eNo = new JRadioButton("NO");
        eNo.setBounds(450,495,90,30);
        eNo.setBackground(Color.WHITE);
        add(eNo);
        
        ButtonGroup existingGroup = new ButtonGroup();
        existingGroup.add(eYes);
        existingGroup.add(eNo);
        
        next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway",Font.BOLD,20));
        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);
        
        
        

        
        
        getContentPane().setBackground(Color.WHITE);
        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
        
    }
    public void actionPerformed(ActionEvent e){ 
        String sreligion = (String) religion.getSelectedItem();//type caste object to string
        String scategory = (String) category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String seducation = (String) education.getSelectedItem();
        String soccupation = (String) occupation.getSelectedItem();

        String span = pan.getText();
        String saadhar = aadhar.getText();
       
        String ssenior = null;
        if(sYes.isSelected()){
            ssenior="Yes";
        }
        else if(sNo.isSelected()){
            ssenior="No";
        }
        
        String saccount = null;
        if(eYes.isSelected()){
            saccount = "Yes";
        }
        else if(eNo.isSelected()){
            saccount="No";
        }
        
        
       
       
        
       try{
          Conn c = new Conn();
               String query = "insert into SignUpTwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+soccupation+"','"+span+"','"+saadhar+"','"+ssenior+"','"+saccount+"')";
               c.s.executeUpdate(query); 
               
               // Signup3 class object
               setVisible(false);
               new SignUpThree(formno).setVisible(true);
               
             
        }catch (Exception a){
           System.out.println(a); 
       }
    }
    public static void main(String args[]) {
      new SignUpTwo("");
    }
}
